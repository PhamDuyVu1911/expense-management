-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2023 at 06:54 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `expense-management`
--

-- --------------------------------------------------------

--
-- Table structure for table `group_transactions`
--

CREATE TABLE `group_transactions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `create_at` datetime NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT NULL,
  `type_transaction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `group_transactions`
--

INSERT INTO `group_transactions` (`id`, `name`, `status`, `create_at`, `update_at`, `type_transaction_id`, `user_id`) VALUES
(6, 'Mua sắm', 0, '2023-11-17 13:17:09', NULL, 1, 2),
(7, 'abc', 0, '2023-11-17 14:30:49', NULL, 2, 2),
(8, 'Mua quần áo', 0, '2023-11-17 14:37:54', NULL, 2, 2),
(9, 'Sinh hoạt', 1, '2023-11-17 20:08:38', NULL, 2, 4),
(10, 'Lương tháng 1', 0, '2023-11-17 20:08:50', '2023-11-20 22:11:33', 1, 4),
(11, 'Sở thích cá nhân', 1, '2023-11-17 20:09:06', NULL, 2, 4),
(12, 'Tiền lãi cho vay', 1, '2023-11-17 20:09:20', NULL, 1, 4),
(13, 'demo', 0, '2023-11-20 22:06:05', NULL, 2, 4),
(14, '123', 1, '2023-11-29 15:29:22', NULL, 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `saving_accounts`
--

CREATE TABLE `saving_accounts` (
  `id` int(11) NOT NULL,
  `depositAmount` float NOT NULL,
  `total_amount` float DEFAULT 0,
  `interestRate` decimal(5,2) NOT NULL,
  `durationInMonths` int(11) NOT NULL,
  `openingDate` datetime NOT NULL DEFAULT current_timestamp(),
  `spending_account_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `user_id` int(11) NOT NULL,
  `create_at` date NOT NULL DEFAULT current_timestamp(),
  `update_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `saving_accounts`
--

INSERT INTO `saving_accounts` (`id`, `depositAmount`, `total_amount`, `interestRate`, `durationInMonths`, `openingDate`, `spending_account_id`, `status`, `user_id`, `create_at`, `update_at`) VALUES
(5, 200000, 203250, 6.50, 3, '2023-11-30 15:58:49', 13, 0, 4, '2023-11-30', NULL),
(6, 300000, 320700, 6.90, 12, '2023-12-04 23:01:43', 13, 0, 4, '2023-12-04', NULL),
(8, 200000, 213800, 6.90, 12, '2023-12-05 00:39:23', 16, 0, 4, '2023-12-05', NULL),
(9, 200000, 213800, 6.90, 12, '2023-12-05 00:48:20', 13, 0, 4, '2023-12-05', NULL),
(10, 200000, 0, 6.90, 12, '2023-12-05 00:54:03', 20, 0, 4, '2023-12-05', NULL),
(11, 200000, 0, 6.50, 3, '2023-12-05 00:54:13', 20, 0, 4, '2023-12-05', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `spending_accounts`
--

CREATE TABLE `spending_accounts` (
  `id` int(11) NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `initial_amount` float NOT NULL,
  `amount` float DEFAULT NULL,
  `type_account` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `create_at` datetime NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `spending_accounts`
--

INSERT INTO `spending_accounts` (`id`, `name`, `initial_amount`, `amount`, `type_account`, `description`, `status`, `create_at`, `update_at`, `user_id`) VALUES
(13, 'Tài khoản nhận lương', 700000, 591000, 'Ngân hàng', 'Tài khoản nhận lương', 1, '2023-11-17 20:07:28', '2023-12-05 00:49:09', 4),
(14, 'Sacombank', 2000000, 2000000, 'Ngân hàng', 'Tài khoản chi tiêu', 1, '2023-11-17 20:07:46', '2023-11-20 22:40:02', 4),
(15, 'Momo - 01312312131', 200000, 170000, 'Ví điện tử', 'Tiền chi tiêu phụ', 1, '2023-11-17 20:08:18', '2023-11-20 22:40:02', 4),
(16, 'Demo', 200000, 213800, 'Ví điện tử', 'Demo', 1, '2023-11-20 22:02:11', '2023-12-05 00:47:49', 4),
(17, 'test', 10000, 5000, 'Ngân hàng', 'abc', 1, '2023-11-29 15:24:57', '2023-11-29 15:25:24', 4),
(18, '1313132123', 500000, NULL, 'Abc', 'Tài khoản mua sắm', 1, '2023-11-29 17:10:29', NULL, 6),
(19, 'saving', 20000, 10000, 'Ví điện tử', 'ok', 1, '2023-11-30 01:32:55', '2023-11-30 01:33:18', 4),
(20, 'test', 100000, NULL, 'ngân hàng', 'đwq', 0, '2023-12-05 00:53:33', '2023-12-05 00:54:13', 4);

-- --------------------------------------------------------

--
-- Table structure for table `spending_plans`
--

CREATE TABLE `spending_plans` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `money_number` float NOT NULL,
  `time` date NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `create_at` datetime NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT NULL,
  `group_transaction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `money_number` float NOT NULL,
  `time` datetime DEFAULT current_timestamp(),
  `img` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `detail` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `create_at` datetime NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT NULL,
  `group_transaction_id` int(11) NOT NULL,
  `spending_account_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `money_number`, `time`, `img`, `description`, `detail`, `status`, `create_at`, `update_at`, `group_transaction_id`, `spending_account_id`, `user_id`) VALUES
(23, 20000, '2023-11-17 20:09:37', NULL, 'Không có', 'Không có', 1, '2023-11-17 20:09:37', NULL, 9, 15, 4),
(24, 5000000, '2023-11-17 20:10:02', NULL, 'Không có', 'Không có', 0, '2023-11-17 20:10:02', NULL, 10, 14, 4),
(25, 200000, '2023-11-17 20:10:34', NULL, 'Không có', 'Không có', 1, '2023-11-17 20:10:34', NULL, 12, 13, 4),
(26, 10000, '2023-11-17 20:10:46', NULL, 'Không có', 'Không có', 1, '2023-11-17 20:10:46', NULL, 9, 15, 4),
(27, 10000, '2023-11-20 22:02:40', NULL, 'Không có', 'Không có', 0, '2023-11-20 22:02:40', NULL, 10, 16, 4),
(28, 10000, '2023-11-20 22:17:56', NULL, '<p>Không có</p>', '<p>Không có</p>', 0, '2023-11-20 22:17:56', '2023-11-20 22:18:19', 10, 14, 4),
(29, 20000, '2023-11-20 22:22:28', NULL, 'Không có', 'Không có', 0, '2023-11-20 22:22:28', NULL, 10, 15, 4),
(30, 5000, '2023-11-29 15:25:24', NULL, 'Không có', 'Không có', 1, '2023-11-29 15:25:24', NULL, 9, 17, 4),
(31, 10000, '2023-11-30 01:33:18', NULL, 'Không có', 'Không có', 1, '2023-11-30 01:33:18', NULL, 9, 19, 4);

-- --------------------------------------------------------

--
-- Table structure for table `type_transactions`
--

CREATE TABLE `type_transactions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `create_at` datetime NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `type_transactions`
--

INSERT INTO `type_transactions` (`id`, `name`, `status`, `create_at`, `update_at`) VALUES
(1, 'Thu', 1, '2023-11-14 14:04:01', NULL),
(2, 'Chi', 1, '2023-11-14 14:04:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `phone_number` int(11) NOT NULL,
  `address` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT NULL,
  `spending_limit` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `phone_number`, `address`, `password`, `status`, `create_at`, `update_at`, `spending_limit`) VALUES
(2, 'Nguyễn Văn A', 'nguyenvana@gmail.com', 123456789, 'Cần Thơ', '123', 1, '2023-11-17 13:12:39', NULL, NULL),
(4, 'Demo', 'demo@gmail.com', 12341221, 'TP.HCM', '123', 1, '2023-11-17 19:44:45', '2023-11-30 16:43:33', 40000),
(5, 'admin', 'admin@gmail.com', 123, 'Cần thơ', '123', 1, '2023-11-19 15:29:15', NULL, NULL),
(6, 'abc', 'abc@gmail.com', 131312, 'Cần Thơ', '123', 1, '2023-11-29 15:26:32', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `group_transactions`
--
ALTER TABLE `group_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type_transaction_id` (`type_transaction_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `saving_accounts`
--
ALTER TABLE `saving_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `spending_accounts_id` (`spending_account_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `spending_accounts`
--
ALTER TABLE `spending_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `spending_plans`
--
ALTER TABLE `spending_plans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_transaction_id` (`group_transaction_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_transaction_id` (`group_transaction_id`),
  ADD KEY `spending_account_id` (`spending_account_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `type_transactions`
--
ALTER TABLE `type_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `group_transactions`
--
ALTER TABLE `group_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `saving_accounts`
--
ALTER TABLE `saving_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `spending_accounts`
--
ALTER TABLE `spending_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `spending_plans`
--
ALTER TABLE `spending_plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `type_transactions`
--
ALTER TABLE `type_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `group_transactions`
--
ALTER TABLE `group_transactions`
  ADD CONSTRAINT `group_transactions_ibfk_1` FOREIGN KEY (`type_transaction_id`) REFERENCES `type_transactions` (`id`),
  ADD CONSTRAINT `group_transactions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `saving_accounts`
--
ALTER TABLE `saving_accounts`
  ADD CONSTRAINT `saving_accounts_ibfk_1` FOREIGN KEY (`spending_account_id`) REFERENCES `spending_accounts` (`id`),
  ADD CONSTRAINT `saving_accounts_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `spending_accounts`
--
ALTER TABLE `spending_accounts`
  ADD CONSTRAINT `spending_accounts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `spending_plans`
--
ALTER TABLE `spending_plans`
  ADD CONSTRAINT `spending_plans_ibfk_1` FOREIGN KEY (`group_transaction_id`) REFERENCES `group_transactions` (`id`),
  ADD CONSTRAINT `spending_plans_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`group_transaction_id`) REFERENCES `group_transactions` (`id`),
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`spending_account_id`) REFERENCES `spending_accounts` (`id`),
  ADD CONSTRAINT `transactions_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
